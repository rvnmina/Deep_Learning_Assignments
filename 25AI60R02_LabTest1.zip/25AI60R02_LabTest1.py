# %% [markdown]
# # Question 1: Load the Digits Dataset
# 
# Load the digits dataset from sklearn and explore its properties.
# The dataset contains 8x8 images of handwritten digits (0-9).
# 
# https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_digits.html

# %%
from sklearn.datasets import load_digits
import matplotlib.pyplot as plt
import numpy as np
digits = load_digits()

# %%
digits.data.shape

# %%
digits.images.shape

# %%
digits.target.shape

# %%
#for fnding no of classes
np.unique(digits.target)

# %%
digits.data.min()

# %%
digits.data.max()

# %%
plt.imshow(digits.images[1], cmap="gray")
plt.title("Label: " + str(digits.target[1]))
plt.axis("off")
plt.show()

# %% [markdown]
# # Question 2: Dataset Splitting (1 mark)
# 
# Divide the dataset into training (70%), validation (15%), and test (15%) sets.
# Use random_state for reproducibility.

# %%
from sklearn.model_selection import train_test_split
X, y = digits.data, digits.target

X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.30, random_state=42)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.50, random_state=42)

print(X_train.shape, X_val.shape, X_test.shape)

# %% [markdown]
# # Question 3: Neural Network Design from Scratch (5 marks)
# 
# Implement a fully connected feedforward neural network from scratch using NumPy.
# Architecture:
# - Input layer: 64 features (8x8 pixels)
# - Hidden layer 1: 128 neurons with ReLU activation and dropout
# - Hidden layer 2: 64 neurons with ReLU activation and dropout
# - Output layer: 10 neurons with softmax activation
# 
# Key implementations:
# - Softmax activation function
# - Gradient through softmax
# - Dropout regularization

# %%
class FeedforwardNeuralNetwork:
    def __init__(
        self,
        num_input_features,
        num_hidden_units_layer1,
        num_hidden_units_layer2,
        num_output_classes,
        dropout_probability=0.2
    ):
        rnd = np.random.RandomState(42)
        self.drop_rate = dropout_probability

        #initialization used
        self.w_in_h1 = rnd.randn(num_input_features, num_hidden_units_layer1) * np.sqrt(2.0 / num_input_features)
        self.b_in_h1 = np.zeros((1, num_hidden_units_layer1))
        self.w_h1_h2 = rnd.randn(num_hidden_units_layer1, num_hidden_units_layer2) * np.sqrt(2.0 / num_hidden_units_layer1)
        self.b_h1_h2 = np.zeros((1, num_hidden_units_layer2))
        #smaller scaling for output layer
        self.w_h2_out = rnd.randn(num_hidden_units_layer2, num_output_classes) * np.sqrt(1.0 / num_hidden_units_layer2)
        self.b_h2_out = np.zeros((1, num_output_classes))
        self.grad_store = {}
        self.mem = {}   # used to store forward values for backprop
        self.is_training = True

    def relu(self, pre_activation):
        return np.maximum(0.0, pre_activation)
    def relu_derivative(self, pre_activation):
        return (pre_activation > 0.0).astype(pre_activation.dtype)
    def softmax(self, logits):
      #subtract max
        z = logits - np.max(logits, axis=1, keepdims=True)
        e = np.exp(z)
        return e / np.sum(e, axis=1, keepdims=True)

    def dropout(self, activations, dropout_probability):
      #dropout apply during training
        if (not self.is_training) or dropout_probability <= 0.0:
            return activations, None
        keep = 1.0 - dropout_probability
        m = (np.random.rand(*activations.shape) < keep).astype(activations.dtype)
        return (activations * m) / keep, m

    def forward(self, input_batch):
      #layer 1
        z1 = input_batch @ self.w_in_h1 + self.b_in_h1
        a1 = self.relu(z1)
        a1_d, m1 = self.dropout(a1, self.drop_rate)
        #layer 2
        z2 = a1_d @ self.w_h1_h2 + self.b_h1_h2
        a2 = self.relu(z2)
        a2_d, m2 = self.dropout(a2, self.drop_rate)
        #output layer with softmax
        z3 = a2_d @ self.w_h2_out + self.b_h2_out
        probs = self.softmax(z3)
        #for backward pass
        self.mem = {
            "x": input_batch,
            "z1": z1, "a1": a1, "a1_d": a1_d, "m1": m1,
            "z2": z2, "a2": a2, "a2_d": a2_d, "m2": m2,
            "z3": z3, "probs": probs
        }
        return probs

    def backward(self, input_batch, target_labels):
        probs = self.mem["probs"]
        n = input_batch.shape[0]
        #convert labels
        y_onehot = np.zeros_like(probs)
        y_onehot[np.arange(n), target_labels] = 1.0
        #gradient at output
        dz3 = (probs - y_onehot) / n
        dw3 = self.mem["a2_d"].T @ dz3
        db3 = np.sum(dz3, axis=0, keepdims=True)
        da2_d = dz3 @ self.w_h2_out.T
        #apply dropout mask
        if self.is_training and self.mem["m2"] is not None and self.drop_rate > 0.0:
            keep = 1.0 - self.drop_rate
            da2 = (da2_d * self.mem["m2"]) / keep
        else:
            da2 = da2_d

        dz2 = da2 * self.relu_derivative(self.mem["z2"])
        dw2 = self.mem["a1_d"].T @ dz2
        db2 = np.sum(dz2, axis=0, keepdims=True)

        da1_d = dz2 @ self.w_h1_h2.T
        if self.is_training and self.mem["m1"] is not None and self.drop_rate > 0.0:
            keep = 1.0 - self.drop_rate
            da1 = (da1_d * self.mem["m1"]) / keep
        else:
            da1 = da1_d

        dz1 = da1 * self.relu_derivative(self.mem["z1"])
        dw1 = input_batch.T @ dz1
        db1 = np.sum(dz1, axis=0, keepdims=True)
        self.grad_store = {
            "dw1": dw1, "db1": db1,
            "dw2": dw2, "db2": db2,
            "dw3": dw3, "db3": db3
        }

    def update_parameters(self, learning_rate):
      #simple SGD
        self.w_in_h1 -= learning_rate * self.grad_store["dw1"]
        self.b_in_h1 -= learning_rate * self.grad_store["db1"]
        self.w_h1_h2 -= learning_rate * self.grad_store["dw2"]
        self.b_h1_h2 -= learning_rate * self.grad_store["db2"]
        self.w_h2_out -= learning_rate * self.grad_store["dw3"]
        self.b_h2_out -= learning_rate * self.grad_store["db3"]

    def predict(self, input_batch):
        prev = self.is_training
        self.is_training = False
        out = self.forward(input_batch)
        self.is_training = prev
        return np.argmax(out, axis=1)


# %% [markdown]
# # Question 4: Loss Function Implementation (1 marks)

# %%
def categorical_cross_entropy(Y_pred, Y_true):
    batch_n = Y_pred.shape[0]
    tiny = 1e-12
    safe_probs = np.clip(Y_pred, tiny, 1.0 - tiny)

    labels_onehot = np.zeros_like(safe_probs)
    labels_onehot[np.arange(batch_n), Y_true] = 1.0

    loss_value = -np.sum(labels_onehot * np.log(safe_probs)) / batch_n
    return loss_value

# %% [markdown]
# # Question 5: Training with Mini-batch Gradient Descent (2 marks)
# 
# 
# 

# %%
def train_model(net, train_x, train_y, val_x, val_y,
                epochs=100, learning_rate=0.1, batch_size=32):

    n_train = train_x.shape[0]
    loss_tr = []
    loss_va = []

    for ep in range(epochs):
      #shuffle data
        order = np.random.permutation(n_train)
        x_shuf = train_x[order]
        y_shuf = train_y[order]
        running_loss = 0.0
        #mini-batch gradient descent loop
        for start in range(0, n_train, batch_size):
            end = start + batch_size
            xb = x_shuf[start:end]
            yb = y_shuf[start:end]

            net.is_training = True #enable dropout during training
            p = net.forward(xb)
            #compute
            step_loss = categorical_cross_entropy(p, yb)
            running_loss += step_loss * xb.shape[0]
            net.backward(xb, yb)
            net.update_parameters(learning_rate)
        running_loss /= n_train
        #validation phase
        net.is_training = False
        val_p = net.forward(val_x)
        val_loss = categorical_cross_entropy(val_p, val_y)

        loss_tr.append(running_loss)
        loss_va.append(val_loss)

        print(f"epoch {ep+1}/{epochs}  train_loss={running_loss:.4f}  val_loss={val_loss:.4f}")
    return loss_tr, loss_va

# %%
def plot_loss(train_losses, val_losses, title="Training and Validation Loss"):
    ep_range = range(1, len(train_losses) + 1)

    plt.figure()
    plt.plot(ep_range, train_losses)
    plt.plot(ep_range, val_losses)

    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.title(title)
    plt.legend(["train", "validation"])
    plt.show()

# %%
net = FeedforwardNeuralNetwork(
    num_input_features=64,
    num_hidden_units_layer1=128,
    num_hidden_units_layer2=64,
    num_output_classes=10,
    dropout_probability=0.2
)

train_losses, val_losses = train_model(net, X_train, y_train, X_val, y_val, epochs=30, learning_rate=0.1, batch_size=32)
plot_loss(train_losses, val_losses)

# %% [markdown]
# # Question 6: Save Model Weights (1 mark)

# %%
import os
import numpy as np

def save_model_weights(model, file_name="./model_weights.npz"):
    folder = os.path.dirname(file_name)
    if folder and not os.path.exists(folder):
        os.makedirs(folder, exist_ok=True)

    np.savez(
        file_name,
        w_in_h1=model.w_in_h1,
        b_in_h1=model.b_in_h1,
        w_h1_h2=model.w_h1_h2,
        b_h1_h2=model.b_h1_h2,
        w_h2_out=model.w_h2_out,
        b_h2_out=model.b_h2_out
    )

# %% [markdown]
# # Question 7: Load Weights and Evaluate on Test Set (2 marks)
# 
# Load the saved weights and perform comprehensive evaluation on the test set.
# Report accuracy, precision, recall, and confusion matrix.

# %%
from sklearn.metrics import accuracy_score, precision_score, recall_score, confusion_matrix
def load_model_weights(model):
    data = np.load(file_name)
    model.w_in_h1 = data["w_in_h1"]
    model.b_in_h1 = data["b_in_h1"]
    model.w_h1_h2 = data["w_h1_h2"]
    model.b_h1_h2 = data["b_h1_h2"]
    model.w_h2_out = data["w_h2_out"]
    model.b_h2_out = data["b_h2_out"]
#load weights
test_model = FeedforwardNeuralNetwork(
    num_input_features=64,
    num_hidden_units_layer1=128,
    num_hidden_units_layer2=64,
    num_output_classes=10,
    dropout_probability=0.2
)
#perform inference
y_pred_test = test_model.predict(X_test)

#calculate metrics
acc_val = accuracy_score(y_test, y_pred_test)
prec_val = precision_score(y_test, y_pred_test, average="macro")
rec_val = recall_score(y_test, y_pred_test, average="macro")

print("Accuracy:", acc_val)
print("Precision:", prec_val)
print("Recall:", rec_val)

# %%
#confusion Matrix
conf_mat = confusion_matrix(y_test, y_pred_test)
print("Confusion Matrix:\n", conf_mat)

# %% [markdown]
# # Question 8: PyTorch Implementation (3 marks)
# 
# Implement a fully connected feedforward neural network from scratch using Pytorch. Architecture:
# 
#     Input layer: 64 features (8x8 pixels)
#     Hidden layer 1: 128 neurons with ReLU activation and dropout
#     Hidden layer 2: 64 neurons with ReLU activation and dropout
#     Output layer: 10 neurons with softmax activation
# 
# Key implementations:
# 
#     Softmax activation function
#     Gradient through softmax
#     Dropout regularization
# 

# %%
import torch
import torch.nn as nn
import torch.nn.functional as F
class PyTorchNN(nn.Module):
    def __init__(self, input_size, hidden1_size, hidden2_size, output_size, dropout_rate=0.2):
        super().__init__()
        self.fc1 = nn.Linear(input_size, hidden1_size)
        self.dp1 = nn.Dropout(dropout_rate)
        self.fc2 = nn.Linear(hidden1_size, hidden2_size)
        self.dp2 = nn.Dropout(dropout_rate)
        self.fc3 = nn.Linear(hidden2_size, output_size)
    def forward(self, x):
        x = self.fc1(x)
        x = F.relu(x)
        x = self.dp1(x)
        x = self.fc2(x)
        x = F.relu(x)
        x = self.dp2(x)
        x = self.fc3(x)
        x = F.softmax(x, dim=1)
        return x

# %% [markdown]
# # Question 9: Train PyTorch Model and Save the Trained Model Weights (2 marks):

# %%
from torch.utils.data import TensorDataset, DataLoader
import torch.optim as optim
device = "cuda" if torch.cuda.is_available() else "cpu"
#convert numpy arrays to PyTorch
train_ds = TensorDataset(torch.tensor(X_train, dtype=torch.float32),
                         torch.tensor(y_train, dtype=torch.long))
val_ds   = TensorDataset(torch.tensor(X_val, dtype=torch.float32),
                         torch.tensor(y_val, dtype=torch.long))
test_ds  = TensorDataset(torch.tensor(X_test, dtype=torch.float32),
                         torch.tensor(y_test, dtype=torch.long))
#create dataloaders
train_loader = DataLoader(train_ds, batch_size=32, shuffle=True)
val_loader   = DataLoader(val_ds, batch_size=64, shuffle=False)
test_loader  = DataLoader(test_ds, batch_size=64, shuffle=False)

def train_torch_model(net, train_loader, val_loader, epochs=20, lr=0.01, device="cpu"):
    net.to(device)
    opt = optim.SGD(net.parameters(), lr=lr)  # simple SGD optimizer

    tr_losses = []
    va_losses = []
    for ep in range(epochs):
        net.train()   #enable dropout
        running = 0.0

        for xb, yb in train_loader:
            xb = xb.to(device)
            yb = yb.to(device)

            opt.zero_grad()
            probs = net(xb)
            #manual crossentropy
            picked = probs.gather(1, yb.view(-1, 1)).squeeze(1)
            loss = -(picked + 1e-12).log().mean()

            loss.backward()
            opt.step()
            running += loss.item() * xb.size(0)
        train_loss = running / len(train_loader.dataset)
        tr_losses.append(train_loss)
        net.eval()   #disable dropot
        val_running = 0.0
        with torch.no_grad():   #no grad during calcultion
            for xv, yv in val_loader:
                xv = xv.to(device)
                yv = yv.to(device)
                p = net(xv)
                picked_v = p.gather(1, yv.view(-1, 1)).squeeze(1)
                v_loss = -(picked_v + 1e-12).log().mean()
                val_running += v_loss.item() * xv.size(0)
        val_loss = val_running / len(val_loader.dataset)
        va_losses.append(val_loss)
        print(f"epoch {ep+1}/{epochs}  train_loss={train_loss:.4f}  val_loss={val_loss:.4f}")
    return tr_losses, va_losses

# %%
def save_torch_weights(model, file_name="./pytorch_model.pt"):
    folder = os.path.dirname(file_name)
    if folder and not os.path.exists(folder):
        os.makedirs(folder, exist_ok=True)
    torch.save(
        {
            "fc1_w": model.fc1.weight.detach().cpu(),
            "fc1_b": model.fc1.bias.detach().cpu(),
            "fc2_w": model.fc2.weight.detach().cpu(),
            "fc2_b": model.fc2.bias.detach().cpu(),
            "fc3_w": model.fc3.weight.detach().cpu(),
            "fc3_b": model.fc3.bias.detach().cpu(),
            "drop_rate": getattr(model.dp1, "p", 0.0),
        },
        file_name
    )
pt_model = PyTorchNN(64, 128, 64, 10, dropout_rate=0.2)
pt_train_losses, pt_val_losses = train_torch_model(pt_model, train_loader, val_loader, epochs=20, lr=0.01, device=device)

save_torch_weights(pt_model, "./pytorch_model.pt")
print("saved:", os.path.exists("./pytorch_model.pt"), "./pytorch_model.pt")

# %% [markdown]
# # Question 10: Load and Evaluate PyTorch Model (2 marks)

# %%
from sklearn.metrics import accuracy_score, precision_score, recall_score, confusion_matrix

def load_torch_weights(model, file_name="./pytorch_model.pt", device="cpu"):
    ckpt = torch.load(file_name, map_location="cpu")
    model.fc1.weight.data.copy_(ckpt["fc1_w"])
    model.fc1.bias.data.copy_(ckpt["fc1_b"])
    model.fc2.weight.data.copy_(ckpt["fc2_w"])
    model.fc2.bias.data.copy_(ckpt["fc2_b"])
    model.fc3.weight.data.copy_(ckpt["fc3_w"])
    model.fc3.bias.data.copy_(ckpt["fc3_b"])
    model.to(device)
    return model
pt_test_model = PyTorchNN(64, 128, 64, 10, dropout_rate=0.2)
load_torch_weights(pt_test_model, "./pytorch_model.pt", device=device)
pt_test_model.eval()
pred_list = []
true_list = []
with torch.no_grad():
    for xb, yb in test_loader:
        xb = xb.to(device)
        out = pt_test_model(xb)
        pred = torch.argmax(out, dim=1).cpu().numpy()
        pred_list.append(pred)
        true_list.append(yb.numpy())
y_pred_test = np.concatenate(pred_list)
y_true_test = np.concatenate(true_list)
acc_val = accuracy_score(y_true_test, y_pred_test)
prec_val = precision_score(y_true_test, y_pred_test, average="macro")
rec_val = recall_score(y_true_test, y_pred_test, average="macro")
print("Accuracy:", acc_val)
print("Precision:", prec_val)
print("Recall:", rec_val)

# %%
#confusion Matrix
conf_mat = confusion_matrix(y_true_test, y_pred_test)
print("Confusion Matrix:\n", conf_mat)

# %% [markdown]
# # Question 11: Performance Comparison (1 mark)
# 
# Compare the performance of NumPy and PyTorch implementations.

# %%
from sklearn.metrics import accuracy_score, precision_score, recall_score
import time
import numpy as np
import torch
def eval_numpy_model(np_model, x_te, y_te):
    t0 = time.time()
    y_hat = np_model.predict(x_te)
    t1 = time.time()
    acc = accuracy_score(y_te, y_hat)
    prec = precision_score(y_te, y_hat, average="macro", zero_division=0)
    rec = recall_score(y_te, y_hat, average="macro", zero_division=0)
    return acc, prec, rec, (t1 - t0)
def eval_torch_model(pt_model, te_loader, device="cpu"):
    pt_model.to(device)
    pt_model.eval()
    all_p = []
    all_y = []
    t0 = time.time()
    with torch.no_grad():
        for xb, yb in te_loader:
            xb = xb.to(device).float()
            out = pt_model(xb)
            pred = torch.argmax(out, dim=1).cpu().numpy()
            all_p.append(pred)
            all_y.append(yb.cpu().numpy())
    t1 = time.time()
    y_hat = np.concatenate(all_p)
    y_true = np.concatenate(all_y)
    acc = accuracy_score(y_true, y_hat)
    prec = precision_score(y_true, y_hat, average="macro", zero_division=0)
    rec = recall_score(y_true, y_hat, average="macro", zero_division=0)
    return acc, prec, rec, (t1 - t0)
np_acc, np_prec, np_rec, np_time = eval_numpy_model(net, X_test, y_test)
pt_acc, pt_prec, pt_rec, pt_time = eval_torch_model(pt_test_model, test_loader, device="cpu")
print("NumPy  -> Acc:", np_acc, " Prec:", np_prec, " Rec:", np_rec, " Time(s):", np_time)
print("PyTorch-> Acc:", pt_acc, " Prec:", pt_prec, " Rec:", pt_rec, " Time(s):", pt_time)


